import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const redis = Redis.fromEnv();
const ratelimit = new Ratelimit({
    redis: redis,
    limiter: Ratelimit.slidingWindow(1, "15 s"),
    analytics: true,
});

async function initFirebase() {
    if (!getApps().length) {
        let saRaw = process.env.FIREBASE_SERVICE_ACCOUNT;
        if (!saRaw) throw new Error("MISSING_ENV_VAR");
        saRaw = saRaw.trim();
        if (!saRaw.startsWith('{')) saRaw = Buffer.from(saRaw, 'base64').toString('utf-8');
        if (saRaw.startsWith("'") && saRaw.endsWith("'")) saRaw = saRaw.slice(1, -1);
        let serviceAccount = JSON.parse(saRaw);
        if (serviceAccount.private_key) serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
        initializeApp({ credential: cert(serviceAccount) });
    }
    return { db: getFirestore(), auth: getAuth() }; // Trả về cả DB và Auth
}

async function addFlag(db, userId) {
    if (!userId) return false;
    const userRef = db.collection('users').doc(userId);
    const doc = await userRef.get();
    let flags = doc.exists ? (doc.data().flags || 0) : 0;
    flags += 1;
    const updateData = { flags };
    let isBanned = false;
    if (flags >= 3) {
        updateData.is_disabled = true;
        isBanned = true;
    }
    await userRef.set(updateData, { merge: true });
    return isBanned;
}

export default async function handler(req, res) {
    const allowedOrigin = "https://public-gamma-brown.vercel.app";
    const origin = req.headers.origin;

    if (process.env.NODE_ENV === 'production' && origin !== allowedOrigin) {
        return res.status(403).json({ success: false, message: "FORBIDDEN_ORIGIN" });
    }
    
    res.setHeader('Access-Control-Allow-Origin', origin || "*");
    res.setHeader('Access-Control-Allow-Methods', 'POST');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization'); // [MỚI] Cho phép header Authorization

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

    try {
        const { text, product, stars } = req.body;
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ success: false, message: "UNAUTHORIZED", detail: "Missing or invalid token" });
        }
        
        const idToken = authHeader.split('Bearer ')[1];
        const { db, auth } = await initFirebase();
        
        let decodedToken;
        try {
            decodedToken = await auth.verifyIdToken(idToken);
        } catch (err) {
            return res.status(401).json({ success: false, message: "UNAUTHORIZED", detail: "Token verification failed" });
        }

        const secureUserId = decodedToken.uid;
        const userDoc = await db.collection('users').doc(secureUserId).get();
        if (!userDoc.exists) {
            return res.status(404).json({ success: false, message: "USER_NOT_FOUND" });
        }
        
        const userData = userDoc.data();
        if (userData.is_disabled) {
            return res.status(403).json({ success: false, message: "ACCOUNT_BANNED" });
        }

        const realUsername = userData.username || decodedToken.name || "Anonymous";
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'anonymous';
        const { success: limitOk, reset } = await ratelimit.limit(`comment-limit:${ip}`);

        if (!limitOk) {
            const waitTime = Math.ceil((reset - Date.now()) / 1000);
            const spamKey = `spam_comment:${secureUserId}`;
            const spamCount = await redis.incr(spamKey);
            if (spamCount === 1) await redis.expireat(spamKey, Math.floor(reset / 1000));
            
            if (spamCount === 3) {
                const isBanned = await addFlag(db, secureUserId);
                if (isBanned) return res.status(403).json({ success: false, message: "ACCOUNT_BANNED" });
            }

            return res.status(429).json({
                success: false,
                message: "TOO_MANY_REQUESTS",
                detail: `Please wait for ${waitTime} seconds.`
            });
        }

        if (!text) throw new Error("Missing text");
        const keysRaw = process.env.MODERATOR_KEYS_POOL || "";
        const keysGate = keysRaw.split(",").map(k => k.trim()).filter(k => k);
        const activeKey = keysGate.length > 0 ? keysGate[Math.floor(Math.random() * keysGate.length)] : process.env.MODERATOR_KEYS_POOL;

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);

        const aiRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: { "Authorization": `Bearer ${activeKey}`, "Content-Type": "application/json" },
            signal: controller.signal,
            body: JSON.stringify({
                model: "llama-3.3-70b-versatile",
                messages: [
                    { role: "system", content: "As a content moderator for this website, you must moderate any offensive or inappropriate content and return the correct formatted results. Attension, if the content is unusual and contain strange language that you have never seen before, that is INAPPROPRIATE LANGUAGE. Respond ONLY 'SAFE' or 'BAD'." },
                    { role: "user", content: text }
                ],
                temperature: 0
            })
        });
        clearTimeout(timeoutId);
        
        const aiData = await aiRes.json();
        const aiMessage = aiData.choices?.[0]?.message?.content?.trim().toUpperCase() || "SAFE";

        if (aiMessage.includes("BAD")) {
            const isBanned = await addFlag(db, secureUserId);
            if (isBanned) {
                return res.status(403).json({ success: false, message: "ACCOUNT_BANNED", detail: "3 flags reached." });
            }
            return res.status(400).json({ success: false, message: "INAPPROPRIATE_CONTENT", detail: "1 flag added." });
        }
        await db.collection('comments').add({
            uid: secureUserId,
            name: realUsername,
            product: product || "Unknown",
            stars: parseInt(stars) || 5,
            text: text,
            date: FieldValue.serverTimestamp()
        });

        return res.status(200).json({ success: true });

    } catch (error) {
        return res.status(500).json({ success: false, message: "SERVER_ERROR", detail: error.message });
    }
}