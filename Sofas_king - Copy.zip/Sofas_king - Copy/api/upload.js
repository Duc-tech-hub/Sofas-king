import admin from 'firebase-admin';
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const redis = Redis.fromEnv();
if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
        }),
    });
}

const db = admin.firestore();
const ADMIN_WHITELIST = ["duck.sssop0356@gmail.com", "sangntp.stommy@mindx.net.vn", "wormholevn@gmail.com", "leopowerup@gmail.com"];
async function addFlags(userId, count) {
    const userRef = db.collection('users').doc(userId);
    const doc = await userRef.get();
    let currentFlags = doc.exists ? (doc.data().flags || 0) : 0;
    let newFlags = currentFlags + count;
    
    let isBanned = newFlags >= 3;
    await userRef.set({ 
        flags: newFlags, 
        is_disabled: isBanned 
    }, { merge: true });
    
    return isBanned;
}

export default async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing Token' });
    
    const idToken = authHeader.split('Bearer ')[1];

    try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        const userEmail = decodedToken.email;
        const userId = decodedToken.uid;
        if (!ADMIN_WHITELIST.map(e => e.toLowerCase()).includes(userEmail.toLowerCase())) {
            const isBanned = await addFlags(userId, 2);
            return res.status(403).json({ 
                error: 'Cảnh báo: Bạn không có quyền Admin. Hệ thống đã ghi nhận 2 lá cờ vi phạm.',
                banned: isBanned 
            });
        }
        const { image } = req.body;
        const IMGBB_KEY = process.env.IMGBB_API_KEY;
        const formData = new URLSearchParams();
        formData.append("image", image);

        const imgbbRes = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_KEY}`, {
            method: "POST",
            body: formData
        });

        const result = await imgbbRes.json();
        return res.status(200).json(result);
    } catch (error) {
        return res.status(401).json({ error: 'Token không hợp lệ' });
    }
}