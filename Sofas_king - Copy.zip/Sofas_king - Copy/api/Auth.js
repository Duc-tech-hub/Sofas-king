const admin = require('firebase-admin');
if (!admin.apps.length) {
    try {
        const saRaw = process.env.FIREBASE_SERVICE_ACCOUNT;
        const serviceAccount = JSON.parse(
            saRaw.startsWith('{') ? saRaw : Buffer.from(saRaw, 'base64').toString()
        );
        if (serviceAccount.private_key) {
            serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
        }
        admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
    } catch (e) {
        console.error("Firebase Init Error");
    }
}

const db = admin.firestore();
export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(404).end();
    }
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return res.status(401).end();

    try {
        const idToken = authHeader.split('Bearer ')[1];
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        const { uid, email, firebase } = decodedToken;
        const { address, phoneNumber, username } = req.body;

        const userDocRef = db.collection('users').doc(uid);
        const userDoc = await userDocRef.get();

        if (userDoc.exists && userDoc.data().is_disabled) {
            return res.status(403).end();
        }

        const now = admin.firestore.FieldValue.serverTimestamp();
        const userData = {
            lastLogin: now,
            address: address || "",
            phoneNumber: phoneNumber || ""
        };

        if (!userDoc.exists) {
            await userDocRef.set({
                uid,
                email: email?.toLowerCase() || "",
                username: username || `User_${uid.substring(0, 5)}`,
                is_disabled: false,
                flags: 0,
                createdAt: now,
                provider: firebase.sign_in_provider,
                ...userData
            });
        } else {
            await userDocRef.update(userData);
        }

        return res.status(200).json({ success: true });
    } catch (e) {
        return res.status(500).end();
    }
}