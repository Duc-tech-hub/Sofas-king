import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
const ratelimit = new Ratelimit({
    redis: Redis.fromEnv(),
    limiter: Ratelimit.slidingWindow(1, "60 s"),
    analytics: true,
});

export default async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

    try {
        const { email, password, username } = req.body;
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'anonymous';
        const { success: limitOk } = await ratelimit.limit(`register:${ip}`);
        if (!limitOk) {
            return res.status(429).json({ success: false, message: "TOO_MANY_REQUESTS" });
        }
        if (!getApps().length) {
            let saRaw = process.env.FIREBASE_SERVICE_ACCOUNT;
            if (!saRaw) throw new Error("MISSING_FIREBASE_SERVICE_ACCOUNT");

            saRaw = saRaw.trim();
            if (!saRaw.startsWith('{')) {
                saRaw = Buffer.from(saRaw, 'base64').toString('utf-8');
            }
            if (saRaw.startsWith("'") && saRaw.endsWith("'")) saRaw = saRaw.slice(1, -1);

            let serviceAccount = JSON.parse(saRaw);
            if (serviceAccount.private_key) {
                serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
            }
            initializeApp({ credential: cert(serviceAccount) });
        }

        const db = getFirestore();
        const auth = getAuth();
        const keysRaw = process.env.MODERATOR_KEYS_POOL || "";
        const keysGate = keysRaw.split(",").map(k => k.trim()).filter(k => k);
        const activeKey = keysGate.length > 0 
            ? keysGate[Math.floor(Math.random() * keysGate.length)] 
            : process.env.GROQ_API_KEY;

        const aiRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: { "Authorization": `Bearer ${activeKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({
                model: "llama-3.3-70b-versatile",
                messages: [
                    { role: "system", content: "Moderate offensive content. Respond ONLY 'SAFE' or 'BAD'." },
                    { role: "user", content: username }
                ],
                temperature: 0
            })
        });

        const aiData = await aiRes.json();
        if (aiData.choices?.[0]?.message?.content?.includes("BAD")) {
            return res.status(400).json({ success: false, message: "INAPPROPRIATE_USERNAME" });
        }
        const snapshot = await db.collection('users').where('username', '==', username).get();
        if (!snapshot.empty) {
            return res.status(400).json({ success: false, message: "USERNAME_TAKEN" });
        }
        const userRecord = await auth.createUser({
            email: email,
            password: password,
            displayName: username
        });

        await db.collection('users').doc(userRecord.uid).set({
            uid: userRecord.uid,
            email: email.toLowerCase(),
            username: username,
            is_disabled: false,
            is_setup_complete: true,
            createdAt: new Date(),
        });

        return res.status(200).json({ success: true, uid: userRecord.uid });

    } catch (error) {
        console.error("Backend Error:", error);
        return res.status(500).json({ success: false, message: error.message });
    }
}