import admin from 'firebase-admin';
import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const redis = Redis.fromEnv();
const ratelimit = new Ratelimit({
    redis: redis,
    limiter: Ratelimit.slidingWindow(1, "40 s"),
    analytics: true,
});

async function initFirebaseAndGetDB() {
    if (!getApps().length) {
        let saRaw = process.env.FIREBASE_SERVICE_ACCOUNT;
        if (!saRaw) throw new Error("MISSING_ENV_VAR");
        saRaw = saRaw.trim();
        if (!saRaw.startsWith('{')) saRaw = Buffer.from(saRaw, 'base64').toString('utf-8');
        let serviceAccount = JSON.parse(saRaw);
        if (serviceAccount.private_key) serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
        initializeApp({ credential: cert(serviceAccount) });
    }
    return getFirestore();
}

async function addFlag(db, userId) {
    if (!userId) return false;
    const userRef = db.collection('users').doc(userId);
    const doc = await userRef.get();
    let data = doc.exists ? doc.data() : {};
    let flags = (data.flags || 0) + 1;
    
    const updateData = { flags };
    let isBanned = false;
    if (flags >= 3) {
        updateData.is_disabled = true;
        isBanned = true;
    }
    await userRef.set(updateData, { merge: true });
    return isBanned;
}

export default async function handler(req, res) {
    const allowedOrigin = "https://public-gamma-brown.vercel.app";
    if (process.env.NODE_ENV === 'production' && req.headers.origin !== allowedOrigin) {
        return res.status(403).json({ success: false, message: "FORBIDDEN_ORIGIN" });
    }
    if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

    try {
        const authHeader = req.headers.authorization;
        if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ success: false, message: "AUTH_REQUIRED" });
        
        const idToken = authHeader.split('Bearer ')[1];
        const db = await initFirebaseAndGetDB();
        
        let userId;
        try {
            const decodedToken = await admin.auth().verifyIdToken(idToken);
            userId = decodedToken.uid;
        } catch (e) {
            return res.status(401).json({ success: false, message: "INVALID_TOKEN" });
        }

        const { newUsername } = req.body;
        const { success: limitOk, reset } = await ratelimit.limit(`update-username:${userId}`);
        if (!limitOk) {
            const spamKey = `spam_username:${userId}`;
            const spamCount = await redis.incr(spamKey);
            if (spamCount === 1) await redis.expireat(spamKey, Math.floor(reset / 1000));
            
            if (spamCount >= 3) {
                const isBanned = await addFlag(db, userId);
                if (isBanned) return res.status(403).json({ success: false, message: "ACCOUNT_BANNED" });
            }
            return res.status(429).json({ success: false, message: "TOO_MANY_REQUESTS", detail: `Wait ${Math.ceil((reset - Date.now()) / 1000)}s.` });
        }

        if (!newUsername || newUsername.trim().length < 3) return res.status(400).json({ success: false, message: "INVALID_USERNAME" });
        const keysRaw = process.env.MODERATOR_KEYS_POOL || "";
        const keysGate = keysRaw.split(",").map(k => k.trim()).filter(k => k);
        const activeKey = keysGate.length > 0 ? keysGate[Math.floor(Math.random() * keysGate.length)] : process.env.GROQ_API_KEY;

        const aiRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
            method: "POST",
            headers: { "Authorization": `Bearer ${activeKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({
                model: "llama-3.3-70b-versatile",
                messages: [{ role: "system", content: "Respond ONLY 'SAFE' or 'BAD'. Moderate offensive content." }, { role: "user", content: newUsername }],
                temperature: 0
            })
        });
        const aiData = await aiRes.json();
        if (aiData.choices?.[0]?.message?.content?.toUpperCase().includes("BAD")) {
            const isBanned = await addFlag(db, userId);
            return res.status(400).json({ success: false, message: isBanned ? "ACCOUNT_BANNED" : "INAPPROPRIATE_LANGUAGE" });
        }
        const snapshot = await db.collection('users').where('username', '==', newUsername).get();
        if (!snapshot.empty && !snapshot.docs.some(d => d.id === userId)) {
            return res.status(400).json({ success: false, message: "USERNAME_TAKEN" });
        }

        await db.collection('users').doc(userId).update({ username: newUsername });
        return res.status(200).json({ success: true });

    } catch (error) {
        return res.status(500).json({ success: false, detail: error.message });
    }
}