import admin from 'firebase-admin';
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const redis = Redis.fromEnv();
const ratelimit = new Ratelimit({
    redis: redis,
    limiter: Ratelimit.slidingWindow(1, "60 s"),
});

if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
        }),
    });
}
const db = admin.firestore();

async function addFlags(userId, count) {
    const userRef = db.collection('users').doc(userId);
    const doc = await userRef.get();
    let currentFlags = doc.exists ? (doc.data().flags || 0) : 0;
    let newFlags = currentFlags + count;
    let isBanned = newFlags >= 3;
    await userRef.set({ flags: newFlags, is_disabled: isBanned }, { merge: true });
    return isBanned;
}

export default async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'Unauthorized' });
    const idToken = authHeader.split('Bearer ')[1];

    try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        const userId = decodedToken.uid;
        const userEmail = decodedToken.email || "";
        const { success: limitOk } = await ratelimit.limit(`order-limit:${userId}`);
        if (!limitOk) {
            const spamKey = `spam_order_count:${userId}`;
            const count = await redis.incr(spamKey);
            if (count === 1) await redis.expire(spamKey, 60);

            if (count >= 3) {
                await addFlags(userId, 1);
                return res.status(429).json({ error: 'Spam detected. 1 flag added.' });
            }
            return res.status(429).json({ error: 'Too fast! Slow down.' });
        }
        const { items, address } = req.body;

        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'Cart is empty or invalid data.' });
        }
        let serverCalculatedPrice = 0;
        const validatedItems = [];

        for (const item of items) {
            if (!item.productId) continue;

            const productDoc = await db.collection('products').doc(item.productId).get();

            if (productDoc.exists) {
                const productData = productDoc.data();
                const price = Number(productData.Price) || 0;

                serverCalculatedPrice += (price * item.quantity);

                validatedItems.push({
                    productId: item.productId,
                    quantity: item.quantity,
                    price: price
                });
            }
        }

        if (serverCalculatedPrice === 0) {
            return res.status(400).json({ error: 'Products not found or price is 0.' });
        }
        const userDocRef = await db.collection('users').doc(userId).get();
        const userName = userDocRef.exists ? (userDocRef.data().username || "User") : "User";
        const statusRef = db.collection('history').doc(userId).collection('admin_verify').doc('status');
        await statusRef.set({
            uid: userId,
            userName: userName,
            userEmail: userEmail,
            deliveryAddress: address || "",
            totalBill: serverCalculatedPrice,
            is_waiting: true,
            is_confirmed: false,
            is_rejected: false,
            updatedAt: Date.now()
        });
        const pendingCol = db.collection('history').doc(userId).collection('pending_orders');
        const batch = db.batch();
        const oldDocs = await pendingCol.get();
        oldDocs.forEach(doc => batch.delete(doc.ref));
        for (const item of validatedItems) {
            const productDoc = await db.collection('products').doc(item.productId).get();
            const productName = productDoc.exists ? (productDoc.data().Name || productDoc.data().name) : "Unknown Product";

            const newDocRef = pendingCol.doc();
            batch.set(newDocRef, {
                productId: item.productId,
                Name: productName,
                quantity: item.quantity,
                price: item.price,
                timestamp: Date.now()
            });
        }
        await batch.commit();

        return res.status(200).json({ success: true });
    } catch (error) {
        console.error("Lỗi Backend:", error);
        return res.status(500).json({ error: error.message });
    }
}