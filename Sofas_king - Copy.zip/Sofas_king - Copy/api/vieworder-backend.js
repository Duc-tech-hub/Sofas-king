import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
const ratelimit = new Ratelimit({
    redis: Redis.fromEnv(),
    limiter: Ratelimit.slidingWindow(5, "60 s"),
    analytics: true,
});
export default async function handler(req, res) {
    const allowedOrigin = "https://public-gamma-brown.vercel.app";
    const origin = req.headers.origin;
    
    res.setHeader('Access-Control-Allow-Origin', origin || "*");
    res.setHeader('Access-Control-Allow-Methods', 'GET');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'GET') return res.status(405).send('Method Not Allowed');

    const { uid } = req.query;

    try {
        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'anonymous';
        const { success: limitOk } = await ratelimit.limit(`get-orders-limit:${ip}`);
        if (!limitOk) return res.status(429).json({ success: false, message: "TOO_MANY_REQUESTS" });

        if (!uid) return res.status(400).json({ success: false, message: "MISSING_UID" });
        if (!getApps().length) {
            let saRaw = process.env.FIREBASE_SERVICE_ACCOUNT;
            if (!saRaw) throw new Error("MISSING_ENV_VAR");
            if (!saRaw.startsWith('{')) saRaw = Buffer.from(saRaw, 'base64').toString('utf-8');
            const serviceAccount = JSON.parse(saRaw);
            if (serviceAccount.private_key) serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
            initializeApp({ credential: cert(serviceAccount) });
        }

        const db = getFirestore();
        const [statusSnap, ordersSnap] = await Promise.all([
            db.collection('history').doc(uid).collection('admin_verify').doc('status').get(),
            db.collection('all_orders').where('uid', '==', uid).get()
        ]);

        const pendingOrder = statusSnap.exists ? statusSnap.data() : null;
        const ordersList = ordersSnap.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        })).sort((a, b) => {
            const timeA = a.createdAt?.seconds || a.timestamp || 0;
            const timeB = b.createdAt?.seconds || b.timestamp || 0;
            return timeB - timeA;
        });
        return res.status(200).json({ 
            success: true, 
            pendingOrder, 
            ordersList 
        });

    } catch (error) {
        return res.status(500).json({ success: false, message: "SERVER_ERROR", detail: error.message });
    }
}