# Summary

Date : 2026-03-28 15:04:20

Directory c:\\Users\\ASUS\\Desktop\\01TC-JSI\\SPCK\\public

Total : 59 files,  5270 codes, 37 comments, 701 blanks, all 6008 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 24 | 2,269 | 31 | 291 | 2,591 |
| PostCSS | 17 | 2,004 | 6 | 277 | 2,287 |
| HTML | 18 | 997 | 0 | 133 | 1,130 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 59 | 5,270 | 37 | 701 | 6,008 |
| . (Files) | 3 | 135 | 0 | 23 | 158 |
| css | 16 | 1,968 | 6 | 272 | 2,246 |
| html | 16 | 898 | 0 | 115 | 1,013 |
| js | 24 | 2,269 | 31 | 291 | 2,591 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)