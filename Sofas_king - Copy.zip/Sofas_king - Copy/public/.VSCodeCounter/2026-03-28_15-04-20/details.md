# Details

Date : 2026-03-28 15:04:20

Directory c:\\Users\\ASUS\\Desktop\\01TC-JSI\\SPCK\\public

Total : 59 files,  5270 codes, 37 comments, 701 blanks, all 6008 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [404.html](/404.html) | HTML | 87 | 0 | 15 | 102 |
| [css/403.css](/css/403.css) | PostCSS | 19 | 0 | 4 | 23 |
| [css/Account.css](/css/Account.css) | PostCSS | 133 | 0 | 14 | 147 |
| [css/Adminpanel.css](/css/Adminpanel.css) | PostCSS | 247 | 0 | 41 | 288 |
| [css/History.css](/css/History.css) | PostCSS | 55 | 0 | 8 | 63 |
| [css/Register\_step2.css](/css/Register_step2.css) | PostCSS | 137 | 0 | 13 | 150 |
| [css/Userinfo.css](/css/Userinfo.css) | PostCSS | 194 | 1 | 18 | 213 |
| [css/cart.css](/css/cart.css) | PostCSS | 64 | 0 | 10 | 74 |
| [css/comments.css](/css/comments.css) | PostCSS | 53 | 0 | 10 | 63 |
| [css/forget\_pass.css](/css/forget_pass.css) | PostCSS | 62 | 0 | 11 | 73 |
| [css/login.css](/css/login.css) | PostCSS | 244 | 0 | 32 | 276 |
| [css/pay-form.css](/css/pay-form.css) | PostCSS | 156 | 0 | 24 | 180 |
| [css/privacy.css](/css/privacy.css) | PostCSS | 73 | 5 | 13 | 91 |
| [css/register.css](/css/register.css) | PostCSS | 167 | 0 | 22 | 189 |
| [css/search.css](/css/search.css) | PostCSS | 118 | 0 | 19 | 137 |
| [css/styles.css](/css/styles.css) | PostCSS | 194 | 0 | 23 | 217 |
| [css/vieworder.css](/css/vieworder.css) | PostCSS | 52 | 0 | 10 | 62 |
| [html/403.html](/html/403.html) | HTML | 15 | 0 | 3 | 18 |
| [html/Adminpanel.html](/html/Adminpanel.html) | HTML | 139 | 0 | 10 | 149 |
| [html/Forget\_pass.html](/html/Forget_pass.html) | HTML | 40 | 0 | 4 | 44 |
| [html/History.html](/html/History.html) | HTML | 25 | 0 | 5 | 30 |
| [html/Register\_step2.html](/html/Register_step2.html) | HTML | 35 | 0 | 6 | 41 |
| [html/cart.html](/html/cart.html) | HTML | 26 | 0 | 4 | 30 |
| [html/comments.html](/html/comments.html) | HTML | 25 | 0 | 5 | 30 |
| [html/index.html](/html/index.html) | HTML | 158 | 0 | 12 | 170 |
| [html/login-google.html](/html/login-google.html) | HTML | 36 | 0 | 4 | 40 |
| [html/login.html](/html/login.html) | HTML | 63 | 0 | 10 | 73 |
| [html/pay-form.html](/html/pay-form.html) | HTML | 42 | 0 | 7 | 49 |
| [html/privacy.html](/html/privacy.html) | HTML | 42 | 0 | 6 | 48 |
| [html/product-detail.html](/html/product-detail.html) | HTML | 42 | 0 | 6 | 48 |
| [html/register.html](/html/register.html) | HTML | 65 | 0 | 9 | 74 |
| [html/userinfo.html](/html/userinfo.html) | HTML | 116 | 0 | 19 | 135 |
| [html/vieworder.html](/html/vieworder.html) | HTML | 29 | 0 | 5 | 34 |
| [index.html](/index.html) | HTML | 12 | 0 | 3 | 15 |
| [js/API.js](/js/API.js) | JavaScript | 45 | 1 | 7 | 53 |
| [js/Adminpanel-part1.js](/js/Adminpanel-part1.js) | JavaScript | 164 | 0 | 22 | 186 |
| [js/Adminpanel-part2.js](/js/Adminpanel-part2.js) | JavaScript | 121 | 6 | 21 | 148 |
| [js/Adminpanel-part3.js](/js/Adminpanel-part3.js) | JavaScript | 177 | 0 | 35 | 212 |
| [js/Adminpanel-part4.js](/js/Adminpanel-part4.js) | JavaScript | 183 | 4 | 18 | 205 |
| [js/Adminpanel-part5.js](/js/Adminpanel-part5.js) | JavaScript | 207 | 4 | 13 | 224 |
| [js/Forget\_pass.js](/js/Forget_pass.js) | JavaScript | 41 | 0 | 9 | 50 |
| [js/History.js](/js/History.js) | JavaScript | 62 | 0 | 10 | 72 |
| [js/LoadProducts.js](/js/LoadProducts.js) | JavaScript | 46 | 0 | 1 | 47 |
| [js/Manage\_auth.js](/js/Manage_auth.js) | JavaScript | 83 | 3 | 11 | 97 |
| [js/Manage\_nav\_bar.js](/js/Manage_nav_bar.js) | JavaScript | 17 | 0 | 4 | 21 |
| [js/ProductDetail.js](/js/ProductDetail.js) | JavaScript | 90 | 6 | 16 | 112 |
| [js/Register\_step1.js](/js/Register_step1.js) | JavaScript | 62 | 0 | 6 | 68 |
| [js/Register\_step2.js](/js/Register_step2.js) | JavaScript | 61 | 0 | 7 | 68 |
| [js/Review.js](/js/Review.js) | JavaScript | 125 | 1 | 19 | 145 |
| [js/Review2.js](/js/Review2.js) | JavaScript | 41 | 2 | 7 | 50 |
| [js/Website_management.js](/js/Website_management.js) | JavaScript | 79 | 0 | 10 | 89 |
| [js/cart.js](/js/cart.js) | JavaScript | 140 | 4 | 13 | 157 |
| [js/firebase-config.js](/js/firebase-config.js) | JavaScript | 15 | 0 | 0 | 15 |
| [js/login.js](/js/login.js) | JavaScript | 52 | 0 | 10 | 62 |
| [js/pay.js](/js/pay.js) | JavaScript | 173 | 0 | 19 | 192 |
| [js/search.js](/js/search.js) | JavaScript | 17 | 0 | 0 | 17 |
| [js/userinfo.js](/js/userinfo.js) | JavaScript | 154 | 0 | 17 | 171 |
| [js/vieworder.js](/js/vieworder.js) | JavaScript | 114 | 0 | 16 | 130 |
| [style.css](/style.css) | PostCSS | 36 | 0 | 5 | 41 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)