import { app, auth, db } from "./firebase-config.js";
import { doc, onSnapshot, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";
import { signOut, onAuthStateChanged, isSignInWithEmailLink, signInWithEmailLink } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

const ADMIN_EMAILS = ["Your_admin_emails"];
const handleAccountBanned = async (uid) => {
    onSnapshot(doc(db, "users", uid), async (docSnap) => {
        if (docSnap.exists() && docSnap.data().is_disabled === true) {
            await Swal.fire({
                icon: 'error',
                title: 'ACCOUNT LOCKED',
                text: 'Your account has been permanently disabled due to multiple policy violations (3 strikes accumulated).',
                footer: 'Contact support: duck.sssop0356@gmail.com for more information.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                confirmButtonText: 'I Understand'
            });
            sessionStorage.clear();
            localStorage.removeItem('emailForSignIn');
            await signOut(auth);
            window.location.replace("../html/403.html");
        }
    });
};

async function updateUserLocation(uid) {
    try {
        let city = sessionStorage.getItem('user_city');
        let country = sessionStorage.getItem('user_country');

        if (!city || !country || city === "N/A" || city === "Unknown") {
            try {
                const res = await fetch('https://api.db-ip.com/v2/free/self');
                const data = await res.json();
                if (data && data.city) {
                    city = data.city;
                    country = data.countryName || data.country;
                }
            } catch (err) {
                console.warn("📍 Location API failed.");
            }
        }

        if (country) {
            sessionStorage.setItem('user_city', city || "Unknown City");
            sessionStorage.setItem('user_country', country);
            
            await updateDoc(doc(db, "users", uid), {
                city: city || "Unknown City",
                country: country,
                lastLogin: serverTimestamp()
            }).catch(() => {  });
        }
    } catch (error) {
        console.error("❌ [FIRESTORE ERROR]:", error);
    }
}

const handleMagicLinkLogin = async () => {
    if (isSignInWithEmailLink(auth, window.location.href)) {
        let email = window.localStorage.getItem('emailForSignIn');
        if (!email) {
            const { value: emailInput } = await Swal.fire({
                title: 'Confirm Email',
                input: 'email',
                inputLabel: 'Please enter your email to complete login',
                allowOutsideClick: false
            });
            email = emailInput;
        }

        if (email) {
            try {
                Swal.fire({ title: 'Verifying...', didOpen: () => Swal.showLoading() });
                const result = await signInWithEmailLink(auth, email, window.location.href);
                window.localStorage.removeItem('emailForSignIn');
                await Swal.fire({ icon: 'success', title: 'Welcome back!', timer: 1500, showConfirmButton: false });
                return result.user;
            } catch (error) {
                await Swal.fire('Login Failed', 'The link is expired or invalid.', 'error');
            }
        }
    }
    return null;
};

const checkSecurity = () => {
    return new Promise((resolve) => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) {
                const output = document.querySelector("#inputinfo_username");
                if (output) output.textContent = user.email;

                updateUserLocation(user.uid); 
                handleAccountBanned(user.uid);

                const path = window.location.pathname.toLowerCase();
                if (path.includes("adminpanel.html") && !ADMIN_EMAILS.includes(user.email)) {
                    window.location.replace("../html/403.html");
                    return resolve(null);
                }
            }
            resolve(user);
        });
    });
};

(async () => {
    let user = await handleMagicLinkLogin();
    if (!user) {
        user = await checkSecurity();
    }

    const path = window.location.pathname;
    let fileName = path.split('/').pop().toLowerCase() || "index.html";
    
    const protectedFiles = [
        "adminpanel.html", "cart.html", 
        "history.html", "pay-form.html", "userinfo.html", "vieworder.html"
    ];

    if (protectedFiles.includes(fileName)) {
        if (!user) {
            await new Promise(res => setTimeout(res, 1000));
            if (!auth.currentUser) {
                window.location.replace("../html/403.html");
            }
        }
    }
})();