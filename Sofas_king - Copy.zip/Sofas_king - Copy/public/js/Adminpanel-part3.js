import { db } from './firebase-config.js';
import {
    collection, collectionGroup, onSnapshot,
    doc, updateDoc, getDocs, deleteDoc, addDoc, query, where, getDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

let isOrderSelectMode = false;

const showToast = (message, icon = 'success') => {
    Swal.fire({
        title: message,
        icon: icon,
        timer: 2000,
        showConfirmButton: false,
        toast: true,
        position: 'top-end'
    });
};

const clean = (str) => {
    if (!str) return "";
    if (typeof str !== 'string') return str;
    return str.replace(/[<>"']/g, m => ({
        '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[m]));
};
const loadOrdersToBox = () => {
    const container = document.querySelector('#output-box-orders');
    if (!container) return;

    const q = query(collectionGroup(db, 'admin_verify'), where('is_waiting', '==', true));
    onSnapshot(q, (snapshot) => {
        if (snapshot.empty) {
            container.innerHTML = `<div style='padding:40px; text-align:center; color:#999;'>No pending orders.</div>`;
            return;
        }
        const promises = snapshot.docs.map(async (statusDoc) => {
            const dataStatus = statusDoc.data();
            const userDocRef = statusDoc.ref.parent.parent;
            if (!userDocRef) return "";

            const uid = userDocRef.id;
            let productsHTML = "";

            try {
                const pendingCol = collection(db, "history", uid, "pending_orders");
                const pendingSnap = await getDocs(pendingCol);

                if (!pendingSnap.empty) {
                    pendingSnap.forEach(p => {
                        const data = p.data();
                        const pName = data.Name || data.name || "Unknown Product";
                        productsHTML += `<div class="product-item" style="margin-bottom:5px; font-size:13px;">
                            📦 ${clean(pName)} <b style="color:#2ecc71;">x${data.quantity}</b>
                        </div>`;
                    });
                } else {
                    productsHTML = "<i style='color:#e74c3c; font-size:12px;'>⚠️ DB is empty</i>";
                }
            } catch (err) {
                console.error("Lỗi lấy sản phẩm:", err);
                productsHTML = "<i style='color:red;'>⚠️ Load error</i>";
            }

            const checkboxHTML = isOrderSelectMode
                ? `<div style="margin-right:15px; display:flex; align-items:center;">
                    <input type="checkbox" class="order-checkbox" value="${uid}" data-statusid="${statusDoc.id}" style="width:18px; height:18px;">
                   </div>`
                : "";

            return `
                <div class="order-card" style="display:flex; align-items:center; border:1px solid #eee; margin-bottom:10px; padding:15px; border-radius:10px; background:#fff; box-shadow:0 2px 4px rgba(0,0,0,0.05);">
                    ${checkboxHTML}
                    <div style="flex:1;">
                        <label style="font-size:10px; color:#999; text-transform:uppercase; font-weight:bold;">Customer</label>
                        <div style="font-weight:bold; font-size:15px;">${clean(dataStatus.userName || uid)}</div>
                        <div style="font-size:11px; color:#3498db; margin-top:3px;">📍 ${clean(dataStatus.deliveryAddress || "No Address")}</div>
                    </div>
                    <div style="flex:2; border-left:1px solid #eee; border-right:1px solid #eee; padding:0 15px;">
                        <label style="font-size:10px; color:#999; text-transform:uppercase; font-weight:bold;">Order Details</label>
                        <div style="margin-top:5px;">${productsHTML}</div>
                    </div>
                    <div style="flex:1; text-align:right;">
                        <span style="background:#fff3e0; color:#ef6c00; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:bold;">WAITING</span>
                        <div style="margin-top:10px; font-weight:bold; color:#e67e22; font-size:16px;">${(dataStatus.totalBill || 0).toLocaleString()} VND</div>
                    </div>
                </div>`;
        });
        Promise.all(promises).then(results => {
            container.innerHTML = results.join("");
        }).catch(err => {
            console.error("Lỗi render:", err);
            container.innerHTML = "Error rendering orders.";
        });
    });
};
const handleAccept = async () => {
    const selected = document.querySelectorAll('.order-checkbox:checked');
    if (selected.length === 0) return Swal.fire('Wait!', 'Select orders to accept.', 'info');

    const confirmResult = await Swal.fire({
        title: 'Confirm Orders?',
        text: `Process ${selected.length} order(s)?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#2ecc71'
    });

    if (confirmResult.isConfirmed) {
        try {
            Swal.fire({ title: 'Processing...', didOpen: () => Swal.showLoading() });

            for (const cb of selected) {
                const uid = cb.value;
                const statusId = cb.getAttribute('data-statusid');
                const statusRef = doc(db, "history", uid, "admin_verify", statusId);
                const statusSnap = await getDoc(statusRef);
                const dataStatus = statusSnap.data() || {};
                const finalAddress = dataStatus.deliveryAddress || "No Address Provided";

                const products = [];
                const now = Date.now();
                const pendingCol = collection(db, "history", uid, "pending_orders");
                const pendingSnap = await getDocs(pendingCol);

                for (const pDoc of pendingSnap.docs) {
                    const item = pDoc.data();
                    const finalItem = { ...item, timestamp: now, status: "completed", address: finalAddress };
                    products.push(finalItem);
                    await addDoc(collection(db, "history", uid, "buying_history"), finalItem);
                    if (item.productId) {
                        const productRef = doc(db, "products", item.productId);
                        const pSnap = await getDoc(productRef);
                        if (pSnap.exists()) {
                            const newStock = Math.max(0, (parseInt(pSnap.data().Stock) || 0) - (parseInt(item.quantity) || 0));
                            await updateDoc(productRef, { Stock: newStock });
                        }
                    }
                    await deleteDoc(pDoc.ref);
                }
                if (products.length === 0 && dataStatus.items) {
                    dataStatus.items.forEach(item => products.push({ ...item, status: "completed", address: finalAddress }));
                }

                if (products.length > 0) {
                    await addDoc(collection(db, "all_orders"), {
                        uid: uid,
                        customerName: dataStatus.userName || "Customer",
                        customerEmail: dataStatus.userEmail || "",
                        address: finalAddress,
                        items: products,
                        totalBill: dataStatus.totalBill || 0,
                        status: "packing",
                        createdAt: now
                    });
                }

                await updateDoc(statusRef, {
                    is_waiting: false,
                    is_confirmed: true,
                    updatedAt: now
                });
            }

            Swal.close();
            showToast("Orders accepted!");
            resetMode();
        } catch (e) {
            console.error(e);
            Swal.fire('Error', 'Failed to process.', 'error');
        }
    }
};
const handleDeny = async () => {
    const selected = document.querySelectorAll('.order-checkbox:checked');
    if (selected.length === 0) return Swal.fire('Wait!', 'Select orders to deny.', 'info');

    const confirmDeny = await Swal.fire({
        title: 'Reject Orders?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33'
    });

    if (confirmDeny.isConfirmed) {
        try {
            Swal.fire({ title: 'Rejecting...', didOpen: () => Swal.showLoading() });
            for (const cb of selected) {
                const uid = cb.value;
                const statusId = cb.getAttribute('data-statusid');
                const statusRef = doc(db, "history", uid, "admin_verify", statusId);

                const pendingSnap = await getDocs(collection(db, "history", uid, "pending_orders"));
                for (const pDoc of pendingSnap.docs) await deleteDoc(pDoc.ref);

                await updateDoc(statusRef, {
                    is_waiting: false,
                    is_rejected: true,
                    updatedAt: Date.now()
                });
            }
            Swal.close();
            showToast("Orders denied.");
            resetMode();
        } catch (e) { console.error(e); }
    }
};

const selectBtn = document.querySelector('#select-order');
const acceptBtn = document.querySelector('#accept-order');
const denyBtn = document.querySelector('#deny-order');

const resetMode = () => {
    isOrderSelectMode = false;
    if (selectBtn) selectBtn.textContent = "Select";
    if (acceptBtn) acceptBtn.style.display = "none";
    if (denyBtn) denyBtn.style.display = "none";
    loadOrdersToBox();
};

selectBtn?.addEventListener('click', () => {
    isOrderSelectMode = !isOrderSelectMode;
    selectBtn.textContent = isOrderSelectMode ? "Cancel" : "Select";
    if (acceptBtn) acceptBtn.style.display = isOrderSelectMode ? "inline-block" : "none";
    if (denyBtn) denyBtn.style.display = isOrderSelectMode ? "inline-block" : "none";
    loadOrdersToBox();
});

acceptBtn?.addEventListener('click', handleAccept);
denyBtn?.addEventListener('click', handleDeny);

loadOrdersToBox();