import { auth, db } from "./firebase-config.js";
import {
    doc, setDoc, onSnapshot, getDoc, updateDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";
let requestStartTime = Date.now(); 
let unsubAdminListener = null;
let isProcessingResult = false;

const clearSelectedItems = async (uid) => {
    const cartRef = doc(db, "carts", uid);
    const snap = await getDoc(cartRef);
    if (snap.exists()) {
        const allItems = snap.data().items || [];
        const remainingItems = allItems.filter(item => item.selected === false);
        await setDoc(cartRef, { items: remainingItems });
    }
};

const calculateTotal = async () => {
    const outputMoneyEl = document.getElementById("output_money");
    const sessionData = sessionStorage.getItem('checkoutItems');
    const selectedItems = sessionData ? JSON.parse(sessionData) : [];

    const total = selectedItems.reduce((sum, item) => {
        const price = parseFloat(item.Price) || 0;
        const qty = parseInt(item.quantity) || 0;
        return sum + (price * qty);
    }, 0);

    if (outputMoneyEl) {
        outputMoneyEl.textContent = `Total: ${total.toLocaleString()} VND`;
    }
    return { total, selectedItems };
};

const startListeningAdmin = (uid) => {
    if (unsubAdminListener) unsubAdminListener();

    const statusRef = doc(db, "history", uid, "admin_verify", "status");
    const note = document.getElementById("note");
    const confirmBtn = document.getElementById("confirmed-sent");

    unsubAdminListener = onSnapshot(statusRef, async (docSnap) => {
        if (!docSnap.exists() || isProcessingResult) return;

        const data = docSnap.data();
        const serverUpdateTime = data.updatedAt || 0;
        if ((data.is_confirmed === true || data.is_rejected === true) && serverUpdateTime > requestStartTime) {
            isProcessingResult = true;
            const isReject = data.is_rejected === true;

            await Swal.fire({
                icon: isReject ? 'error' : 'success',
                title: isReject ? 'Order Rejected' : 'Order Confirmed!',
                text: isReject ? 'Your order was declined by Admin. Please check again.' : 'Thank you for your purchase!',
                confirmButtonText: 'OK',
                allowOutsideClick: false
            });

            Swal.fire({
                title: 'Finalizing...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });

            try {
                await Promise.all([
                    clearSelectedItems(uid),
                    updateDoc(statusRef, {
                        is_waiting: false,
                        is_confirmed: false,
                        is_rejected: false,
                        totalBill: 0
                    })
                ]);

                sessionStorage.removeItem('checkoutItems');
                setTimeout(() => {
                    window.location.replace("/index.html");
                }, 150);
            } catch (err) {
                console.error("Redirect Error:", err);
                window.location.href = "/index.html";
            }
            return;
        }
        if (data.is_waiting === true) {
            if (confirmBtn) confirmBtn.style.display = "none";
            if (note) {
                note.style.display = "block";
                note.style.color = "orange";
                note.innerText = "Waiting for Admin to verify your payment...";
            }
        } else {
            if (confirmBtn) {
                confirmBtn.style.display = "block";
                confirmBtn.disabled = false;
                confirmBtn.innerText = "I have sent money.";
            }
            if (note) note.style.display = "none";
            isProcessingResult = false;
        }
    });
};

const handleConfirmRequest = async (user, selectedItems, address, total) => {
    try {
        requestStartTime = Date.now(); 

        const idToken = await user.getIdToken();
        const response = await fetch('/api/create-order', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${idToken}`
            },
            body: JSON.stringify({
                uid: user.uid,
                email: user.email,
                address: address,
                totalPrice: total,
                items: selectedItems.map(i => ({
                    productId: i.productId,
                    quantity: i.quantity,
                    Price: i.Price,
                    Name: i.Name
                }))
            })
        });

        const result = await response.json();
        if (!response.ok) {
            if (result.banned) Swal.fire('Warning', 'Unauthorized price detected', 'error');
            return false;
        }
        return result.success;
    } catch (e) {
        console.error("Fetch Error:", e);
        return false;
    }
};

onAuthStateChanged(auth, async (user) => {
    if (!user) return;

    const addressInput = document.getElementById("address");
    const confirmBtn = document.getElementById("confirmed-sent");
    
    const userSnap = await getDoc(doc(db, "users", user.uid));
    if (userSnap.exists() && addressInput) {
        addressInput.value = userSnap.data().address || "";
    }
    
    const { total, selectedItems } = await calculateTotal();
    startListeningAdmin(user.uid);

    if (confirmBtn) {
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

        newConfirmBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const addressValue = addressInput ? addressInput.value.trim() : "";

            if (!addressValue) {
                return Swal.fire('Notice', 'Please enter your delivery address!', 'warning');
            }

            if (selectedItems.length === 0) {
                return Swal.fire('Empty Selection', 'Please select items to pay!', 'info');
            }

            Swal.fire({
                title: 'Sending Request...',
                text: 'Uploading your order to Cloud Server.',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });

            newConfirmBtn.disabled = true;
            newConfirmBtn.innerText = "Processing...";
            
            const success = await handleConfirmRequest(user, selectedItems, addressValue, total);

            if (success) {
                await Swal.fire({
                    icon: 'success',
                    title: 'Order Created!',
                    text: 'Your request has been sent. Admin will verify it shortly.',
                    confirmButtonText: 'I Understand',
                    confirmButtonColor: '#28a745'
                });
            } else {
                newConfirmBtn.disabled = false;
                newConfirmBtn.innerText = "I have sent money.";
                Swal.fire('Error', 'Failed to send request.', 'error');
            }
        });
    }
});