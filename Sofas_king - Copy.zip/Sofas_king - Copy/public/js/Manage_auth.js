import { auth, db } from "./firebase-config.js";
import { signOut, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

document.addEventListener("DOMContentLoaded", () => {
    const googleMethodButton = document.querySelector("#googlemethod");

    if (googleMethodButton) {
        googleMethodButton.addEventListener("click", async () => {
            const addressValue = document.querySelector("#address")?.value.trim() || "";
            const phoneValue = document.querySelector("#Phone_number")?.value.trim() || "";

            Swal.fire({
                title: 'Connecting to Google...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });

            try {
                const result = await signInWithPopup(auth, googleProvider);
                const user = result.user;
                const idToken = await user.getIdToken();
                const response = await fetch('/api/Auth', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${idToken}`
                    },
                    body: JSON.stringify({ 
                        username: user.displayName,
                        address: addressValue,
                        phoneNumber: phoneValue
                    })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    await signOut(auth);
                    
                    let msg = "Login failed!";
                    if (errorData.error === "ACCOUNT_LOCKED") {
                        msg = "Your account has been disabled. Please contact support.";
                    }
                    throw new Error(msg);
                }
                await Swal.fire({
                    icon: 'success',
                    title: 'Login Successful',
                    timer: 1500,
                    showConfirmButton: false
                });

                window.location.href = "../html/index.html";

            } catch (error) {
                console.error("Login Error:", error);
                
                if (auth.currentUser) await signOut(auth);

                Swal.fire({ 
                    icon: 'error', 
                    title: 'Login Failed', 
                    text: error.message || "System error, please try again."
                });
            }
        });
    }
});