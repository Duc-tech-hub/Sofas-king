import { auth } from "./firebase-config.js";
import { signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

const loginForm = document.querySelector("#login-form");
document.querySelector('.btn-toggle-login')?.addEventListener('click', function () {
    const passwordInput = document.getElementById('login-password');
    passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
    this.classList.toggle('bi-eye');
    this.classList.toggle('bi-eye-slash');
});
loginForm?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const emailInput = document.querySelector("#login-username").value.trim();
    const password = document.querySelector("#login-password").value;
    const addressValue = document.querySelector("#address")?.value.trim() || "";
    const phoneValue = document.querySelector("#Phone_number")?.value.trim() || "";
    Swal.fire({
        title: 'Authenticating...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    try {
        const userCredential = await signInWithEmailAndPassword(auth, emailInput, password);
        const user = userCredential.user;
        const idToken = await user.getIdToken();
        const response = await fetch('/api/Auth', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${idToken}`
            },
            body: JSON.stringify({ 
                address: addressValue, 
                phoneNumber: phoneValue 
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            await signOut(auth);

            let msg = "Login failed!";
            if (errorData.error === "ACCOUNT_LOCKED") {
                msg = "Your account has been disabled. Please contact support.";
            } else if (errorData.error === "Unauthorized") {
                msg = "Session invalid. Please try again.";
            }
            
            throw new Error(msg);
        }
        await Swal.fire({
            icon: 'success',
            title: 'Welcome Back!',
            text: 'Login successful.',
            timer: 1500,
            showConfirmButton: false
        });

        window.location.href = "../html/index.html";

    } catch (error) {
        console.error("Login Error:", error);
        let errorMsg = "Invalid email or password!";
        
        if (error.code === "auth/user-not-found" || error.code === "auth/wrong-password" || error.code === "auth/invalid-credential") {
            errorMsg = "Invalid email or password!";
        } else if (error.code === "auth/too-many-requests") {
            errorMsg = "Too many failed attempts. Try again later!";
        } else if (error.message) {
            errorMsg = error.message;
        }

        Swal.fire({ 
            icon: 'error', 
            title: 'Login Failed', 
            text: errorMsg 
        });
    }
});