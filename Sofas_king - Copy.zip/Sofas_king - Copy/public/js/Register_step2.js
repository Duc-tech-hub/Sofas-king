const securityForm = document.querySelector("#security-form");

securityForm?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.querySelector("#security-answer").value.trim();
    const username = sessionStorage.getItem('temp_username');
    const password = sessionStorage.getItem('temp_password');
    if (!username || !password) {
        return Swal.fire({
            icon: 'error',
            title: 'Session Expired',
            text: 'Please complete Step 1 again.'
        }).then(() => {
            window.location.href = "Register_step1.html";
        });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return Swal.fire('Invalid Email', 'Please enter a valid email address.', 'warning');
    }
    Swal.fire({
        title: 'Finalizing Registration...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    try {
        const response = await fetch("/api/register-user", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, username, password })
        });

        const result = await response.json();

        if (response.ok) {
            sessionStorage.clear();
            Swal.fire({
                icon: 'success',
                title: 'Registration Complete!',
                text: 'Welcome to Sofas-king!',
                timer: 2000,
                showConfirmButton: false
            }).then(() => {
                window.location.replace("login.html");
            });
        } else {
            let errorMsg = result.message || "An error occurred.";
            if (result.message === "INAPPROPRIATE_USERNAME") errorMsg = "Your username is not allowed!";
            if (result.message === "USERNAME_TAKEN") errorMsg = "This username is already taken!";
            if (result.message === "auth/email-already-in-use") errorMsg = "This email is already registered!";

            Swal.fire({ icon: 'error', title: 'Registration Failed', text: errorMsg });
        }
    } catch (err) {
        console.error("Lỗi fetch:", err);
        Swal.fire('Error', 'Không kết nối được server: ' + err.message, 'error');
    }
});