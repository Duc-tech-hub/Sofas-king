const registerForm = document.querySelector("#register-form");
document.querySelectorAll('.btn-toggle').forEach(icon => {
    icon.addEventListener('click', function () {
        const targetId = this.getAttribute('data-target');
        const input = document.getElementById(targetId);
        if (input.type === 'password') {
            input.type = 'text';
            this.classList.replace('bi-eye-slash', 'bi-eye');
            this.classList.add('text-blue-500');
        } else {
            input.type = 'password';
            this.classList.replace('bi-eye', 'bi-eye-slash');
            this.classList.remove('text-blue-500');
        }
    });
});
registerForm?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const username = document.querySelector("#username").value.trim();
    const password = document.querySelector("#password").value;
    const confirmPassword = document.querySelector("#confirm-password").value;
    if (password !== confirmPassword) {
        return Swal.fire({ icon: 'warning', title: 'Oops...', text: 'Passwords do not match!' });
    }

    if (password.length < 8) {
        return Swal.fire({ icon: 'warning', text: 'Password must be at least 8 characters!' });
    }
    Swal.fire({
        title: 'Processing...',
        timer: 800,
        didOpen: () => { Swal.showLoading(); }
    }).then(() => {
        sessionStorage.setItem('temp_username', username);
        sessionStorage.setItem('temp_password', password);
        window.location.assign("Register_step2.html"); 
    });
});